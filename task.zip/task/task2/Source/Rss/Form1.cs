﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Newtonsoft.Json;
using System.IO;

namespace Rss
{
    public partial class Form1 : Form
    {
        private Timer updateTimer;// Таймер для периодического обновления RSS ленты
        private AppConfig config;// Объект конфигурации
        private WebProxy proxy;// Объект прокси-сервера
        public Form1()
        {
            InitializeComponent();
     
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadConfiguration();// Загрузка конфигурации из файла
            InitializeTimer();// Инициализация таймера
            FetchRssFeed();// Начальная загрузка RSS ленты
        }

        private void LoadConfiguration()
        {
            try
            {
                // Чтение конфигурации из файла config.json
                string configText = File.ReadAllText("config.json");
                config = JsonConvert.DeserializeObject<AppConfig>(configText);

                if (!string.IsNullOrEmpty(config.ProxyAddress))
                {
                    proxy = new WebProxy(config.ProxyAddress);
                }
                else
                {
                    proxy = null; // Прокси не используется
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке конфигурации: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(1);
            }
        }

        private void InitializeTimer()
        {
            updateTimer = new Timer();
            updateTimer.Interval = config.UpdateFrequency;// Установка интервала таймера из конфигурации
            updateTimer.Tick += (s, e) => FetchRssFeed();// Добавление обработчика события для обновления RSS ленты
            updateTimer.Start();
        }

        private void FetchRssFeed()
        {
            using (WebClient client = new WebClient())
            {
                if (proxy != null)
                {
                    client.Proxy = proxy;
                }

                try
                {
                    client.Encoding = Encoding.UTF8;
                    string rssData = client.DownloadString(config.RssFeedUrl);// Загрузка RSS ленты
                    XmlDocument xmlDoc = new XmlDocument();// Загрузка RSS данных в XML документ
                    xmlDoc.LoadXml(rssData);

                    XmlNodeList items = xmlDoc.SelectNodes("//item");// Поиск всех элементов item в RSS ленте
                    listBoxItems.Items.Clear();

                    foreach (XmlNode item in items)
                    {
                        string title = item.SelectSingleNode("title").InnerText;
                        string pubDate = item.SelectSingleNode("pubDate").InnerText;
                        string link = item.SelectSingleNode("link").InnerText;
                        string description = item.SelectSingleNode("description").InnerText;

                        DateTime pubDateParsed;
                        if (DateTime.TryParse(pubDate, out pubDateParsed))
                        {
                            pubDate = pubDateParsed.ToString("dd MMM yyyy HH:mm");
                        }
                        // Создание объекта RssItem и добавление его в список
                        var rssItem = new RssItem { Title = title, PubDate = pubDate, Link = link, Description = description };
                        listBoxItems.Items.Add(rssItem);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении RSS ленты: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void listBoxItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxItems.SelectedItem != null)
            {
                // Отображение описания выбранного элемента
                var selectedItem = (RssItem)listBoxItems.SelectedItem;
                labelDescription.Text = selectedItem.Description;
            }
        }

        private void listBoxItems_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listBoxItems.SelectedItem != null)
            {
                // Открытие ссылки в браузере при двойном щелчке по элементу
                var selectedItem = (RssItem)listBoxItems.SelectedItem;
                System.Diagnostics.Process.Start(selectedItem.Link);
            }
        }

        // Класс конфигурации для десериализации из JSON файла
        public class AppConfig
        {
            public string RssFeedUrl { get; set; }
            public int UpdateFrequency { get; set; }
            public string ProxyAddress { get; set; }
        }
    }
    // Класс для хранения данных RSS элемента
    public class RssItem
        {
            public string Title { get; set; }
            public string PubDate { get; set; }
            public string Link { get; set; }
            public string Description { get; set; }
        // Переопределение метода ToString для отображения в ListBox
        public override string ToString()
        {
            return $"{Title} ({PubDate})";
        }
    }
}