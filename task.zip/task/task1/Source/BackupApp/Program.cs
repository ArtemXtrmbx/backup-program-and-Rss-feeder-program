﻿using System;
using System.IO;
using Newtonsoft.Json.Linq;

namespace BackupApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string settingsFile = "appsettings.json";
            if (!File.Exists(settingsFile))
            {
                Console.WriteLine($"Файл настроек '{settingsFile}' не найден.");
                return;
            }

            JObject settings = JObject.Parse(File.ReadAllText(settingsFile));
            string? sourceFolder = settings["SourceFolder"]?.ToString();// Возможно допуск значения NULL (?)
            string? targetFolder = settings["TargetFolder"]?.ToString();

            if (string.IsNullOrEmpty(sourceFolder) || string.IsNullOrEmpty(targetFolder))
            {
                Console.WriteLine("Некорректные пути в файле настроек.");
                return;
            }

            // Создание папки с временным штампом в целевой папке
            string timeStamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
            string backupFolder = Path.Combine(targetFolder, $"Backup_{timeStamp}");

            try
            {
                Directory.CreateDirectory(backupFolder);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Не удалось создать директорию резервного копирования: {ex.Message}");
                return;
            }

            // Копирование файлов из исходной папки в папку резервного копирования
            try
            {
                foreach (string filePath in Directory.GetFiles(sourceFolder))
                {
                    try
                    {
                        string fileName = Path.GetFileName(filePath);
                        string destFile = Path.Combine(backupFolder, fileName);
                        File.Copy(filePath, destFile);
                        Console.WriteLine($"Файл '{fileName}' успешно скопирован.");
                    }
                    catch (UnauthorizedAccessException)
                    {
                        Console.WriteLine($"Нет доступа к файлу '{filePath}'.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка при копировании файла '{filePath}': {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при получении списка файлов из исходной папки: {ex.Message}");
            }
            Console.WriteLine("Резервное копирование завершено.");
        }
    }
}